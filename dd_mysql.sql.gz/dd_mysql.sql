-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 24 2017 г., 11:09
-- Версия сервера: 5.5.53
-- Версия PHP: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `DB-java-ee-1`
--
CREATE DATABASE IF NOT EXISTS `DB-java-ee-1` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `DB-java-ee-1`;

-- --------------------------------------------------------

--
-- Структура таблицы `post`
--

CREATE TABLE `post` (
  `pos_id` int(15) NOT NULL,
  `position` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='должности';

--
-- Дамп данных таблицы `post`
--

INSERT INTO `post` (`pos_id`, `position`) VALUES
(49731344, 'Руководитель IT'),
(211865322, 'Менеджер проектов'),
(425190114, 'Менеджер'),
(451496523, 'Старший программист'),
(515016158, 'Бухгалтер'),
(954946739, 'Программист'),
(1208788123, 'Специалист'),
(1265818147, 'Директор'),
(1953649499, 'Должность'),
(2065716212, 'Директор по маркетингу');

-- --------------------------------------------------------

--
-- Структура таблицы `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `pos_id` int(15) NOT NULL,
  `paycheck` int(11) NOT NULL,
  `login` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='таблица сотрудников';

--
-- Дамп данных таблицы `staff`
--

INSERT INTO `staff` (`id`, `name`, `lname`, `pos_id`, `paycheck`, `login`, `password`) VALUES
(15, 'Петр', 'Петров', 954946739, 100000, 'petr', '9a855b295c6b5c7b92d52bb26f78d930'),
(16, 'Алексей', 'Степанов', 515016158, 60000, 'alexey', 'e10adc3949ba59abbe56e057f20f883e'),
(18, 'Марина', 'Дъякова', 211865322, 110000, 'marina', 'ba00819f263287af1ff0100c5a323355'),
(19, 'Степан', 'Хвостов', 49731344, 110000, 'stepan', 'e10adc3949ba59abbe56e057f20f883e'),
(20, 'Сергей', 'Лунов', 2065716212, 110000, 'sergey', 'ae7937f4a7f699addaca18bed54a6dec'),
(21, 'Михаил', 'Алексеев', 451496523, 100000, 'misha', '248a7e4e87bdc2ab548e4f5cc2897e91'),
(22, 'Ирина', 'Любина', 1265818147, 130000, 'irina', 'ae793a49560ed4784fe643c32b9116e7'),
(24, 'Андрей', 'Лавров', 954946739, 90000, 'andrey', '2c22c5a8c8c09598836dc00451db8c1b');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`pos_id`);

--
-- Индексы таблицы `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_staff_post` (`pos_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `staff`
--
ALTER TABLE `staff`
  ADD CONSTRAINT `FK_staff_post` FOREIGN KEY (`pos_id`) REFERENCES `post` (`pos_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
